package com.example.proyectofinal
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview

class PantallaPerfil : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PantallaPerfilContent()
        }
    }
}

@Composable
fun PantallaPerfilContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE0E0E0))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Card superior con datos del usuario
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFB0BEC5))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Image(
                    painter = painterResource(id = R.drawable.perfil), // Cambia esto a tu imagen de perfil
                    contentDescription = "Perfil",
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Pablo Cabrera", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Edad: 19", fontSize = 16.sp)
                Text("Peso: 95 kg", fontSize = 16.sp)
                Text("IMC: 30.8", fontSize = 16.sp)
            }
        }

        // Botones para navegar a otras pantallas
        Column {
            Row(modifier = Modifier.fillMaxWidth()) {
                OpcionPantalla(
                    imagen = painterResource(id = R.drawable.pantalla_calorias), // Cambia a la imagen correspondiente
                    texto = "Calorías"
                )
                OpcionPantalla(
                    imagen = painterResource(id = R.drawable.pantalla_imc), // Cambia a la imagen correspondiente
                    texto = "IMC"
                )
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                OpcionPantalla(
                    imagen = painterResource(id = R.drawable.pantalla_gemini), // Cambia a la imagen correspondiente
                    texto = "Gemini"
                )
                OpcionPantalla(
                    imagen = painterResource(id = R.drawable.pantalla_otra), // Cambia a la imagen correspondiente
                    texto = "Otra"
                )
            }
        }
    }
}

@Composable
fun OpcionPantalla(imagen: Painter, texto: String) {
    Column(
        modifier = Modifier
            .weight(1f)
            .padding(8.dp)
            .clickable { /* Navegar a la pantalla correspondiente */ },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painter = imagen, contentDescription = texto, modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text, textAlign = TextAlign.Center)
    }
}

@Preview(showBackground = true)
@Composable
fun PantallaPerfilPreview() {
    PantallaPerfilContent()
}
